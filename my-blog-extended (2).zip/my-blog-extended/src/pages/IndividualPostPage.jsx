import { Link, useParams } from "react-router";
import { ArrowLeft } from "lucide-react";
import BlogPost from "../components/BlogPost.jsx";
import blogPosts from "../data/blogPosts.js";

export default function IndividualPostPage({ commentsByPost, onAddComment }) {
  const { postId } = useParams();
  const post = blogPosts.find((item) => item.id === postId);

  if (!post) {
    return (
      <main className="main-content">
        <div className="content-wrap not-found">
          <p className="eyebrow">404 · POST NOT FOUND</p>
          <h1>We couldn't find that post.</h1>
          <Link className="read-more" to="/">Return to all blog posts <ArrowLeft size={15} /></Link>
        </div>
      </main>
    );
  }

  return (
    <main className="main-content">
      <div className="content-wrap">
        <Link className="back-link" to="/"><ArrowLeft size={15} /> All blog posts</Link>
        <div className="intro-label"><span /> FROM THE BLOG</div>
        <BlogPost
          post={post}
          comments={commentsByPost[post.id] || []}
          onAddComment={(comment) => onAddComment(post.id, comment)}
        />
      </div>
    </main>
  );
}
