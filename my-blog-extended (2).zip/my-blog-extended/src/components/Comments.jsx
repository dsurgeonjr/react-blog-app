import { useState } from "react";
import { MessageCircle, Send } from "lucide-react";

export default function Comments({ comments, onAddComment }) {
  const [name, setName] = useState("");
  const [commentText, setCommentText] = useState("");
  const [error, setError] = useState("");

  function handleSubmit(event) {
    event.preventDefault();
    const trimmedName = name.trim();
    const trimmedComment = commentText.trim();

    if (!trimmedName || !trimmedComment) {
      setError("Please enter your name and a comment before submitting.");
      return;
    }

    onAddComment({
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      name: trimmedName,
      text: trimmedComment
    });
    setName("");
    setCommentText("");
    setError("");
  }

  return (
    <section className="comments-section" aria-labelledby="comments-heading">
      <div className="section-heading">
        <span className="section-icon"><MessageCircle size={19} /></span>
        <h2 id="comments-heading">Comments</h2>
        <span className="comment-count">{comments.length}</span>
      </div>

      <form className="comment-form" onSubmit={handleSubmit}>
        <label htmlFor="comment-name">Name</label>
        <input
          id="comment-name"
          type="text"
          value={name}
          onChange={(event) => {
            setName(event.target.value);
            if (error) setError("");
          }}
          placeholder="Your name"
          maxLength={60}
          required
        />

        <label htmlFor="comment-input">Comment</label>
        <textarea
          id="comment-input"
          value={commentText}
          onChange={(event) => {
            setCommentText(event.target.value);
            if (error) setError("");
          }}
          placeholder="Share your thoughts..."
          rows="3"
          maxLength={1000}
          aria-describedby={error ? "comment-error" : undefined}
          required
        />
        {error && <p className="form-error" id="comment-error">{error}</p>}
        <div className="form-bottom">
          <span className="form-hint">Be kind and keep the conversation going.</span>
          <button className="submit-button" type="submit">
            <Send size={15} />
            Submit
          </button>
        </div>
      </form>

      <div className="existing-comments">
        <h3>Existing Comments</h3>
        {comments.length === 0 ? (
          <p className="empty-comments">No comments yet. Be the first to comment!</p>
        ) : (
          <ul className="comment-list">
            {comments.map((comment) => (
              <li key={comment.id}>
                <span className="comment-avatar" aria-hidden="true">
                  {comment.name.charAt(0).toUpperCase()}
                </span>
                <span className="comment-body">
                  <strong>{comment.name}</strong>
                  <span>{comment.text}</span>
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
