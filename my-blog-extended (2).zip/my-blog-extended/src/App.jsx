import { useEffect, useState } from "react";
import { Route, Routes } from "react-router";
import Header from "./components/Header.jsx";
import Footer from "./components/Footer.jsx";
import BlogPostsPage from "./pages/BlogPostsPage.jsx";
import IndividualPostPage from "./pages/IndividualPostPage.jsx";
import ContactPage from "./pages/ContactPage.jsx";
import NotFoundPage from "./pages/NotFoundPage.jsx";
import blogPosts from "./data/blogPosts.js";

function getInitialComments() {
  const defaults = Object.fromEntries(blogPosts.map((post) => [post.id, post.initialComments]));
  try {
    const saved = localStorage.getItem("my-blog-comments");
    return saved ? { ...defaults, ...JSON.parse(saved) } : defaults;
  } catch {
    return defaults;
  }
}

export default function App() {
  const [commentsByPost, setCommentsByPost] = useState(getInitialComments);

  useEffect(() => {
    try {
      localStorage.setItem("my-blog-comments", JSON.stringify(commentsByPost));
    } catch {
      // Comments still work for the current session without browser storage.
    }
  }, [commentsByPost]);

  function addComment(postId, comment) {
    setCommentsByPost((current) => ({
      ...current,
      [postId]: [...(current[postId] || []), comment]
    }));
  }

  return (
    <div className="app-shell">
      <Header />
      <Routes>
        <Route path="/" element={<BlogPostsPage />} />
        <Route
          path="/posts/:postId"
          element={<IndividualPostPage commentsByPost={commentsByPost} onAddComment={addComment} />}
        />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
      <Footer />
    </div>
  );
}
