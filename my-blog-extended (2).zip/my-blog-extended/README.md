# My Blog — Extended React Project

## Features
- Blog posts home page with unique posts
- Individual post pages selected by URL ID
- Like button and like counter on each post
- Comments with commenter name and comment text
- Comments stored per post and saved in localStorage
- Contact form demonstration (no backend)
- React Router navigation
- Light/dark mode using React Context and useState
- Theme preference saved in localStorage
- Responsive CSS styling based on the supplied My Blog design

## Run the project
Requires Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
```

Open the localhost URL printed in the terminal.

## Test a production build
```bash
npm run build
npm run preview
```

## Project structure
```text
src/
  components/
    BlogPost.jsx
    Comments.jsx
    Footer.jsx
    Header.jsx
  context/
    ThemeContext.jsx
  data/
    blogPosts.js
  pages/
    BlogPostsPage.jsx
    IndividualPostPage.jsx
    ContactPage.jsx
    NotFoundPage.jsx
  App.jsx
  index.css
  main.jsx
```

`node_modules` is not included. Run `npm install` after extracting the ZIP.
